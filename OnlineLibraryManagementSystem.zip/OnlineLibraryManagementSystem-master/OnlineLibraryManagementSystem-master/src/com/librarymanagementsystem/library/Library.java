package com.librarymanagementsystem.library;

/**
 * @author Suman Nayak
 * @date  31-08-2025
 * This class is used to create a library object
 */
public class Library {
    private final String LibraryName;
    private final String LibraryAddress;

    public Library(String LibraryName, String LibraryAddress){
        this.LibraryName = LibraryName;
        this.LibraryAddress = LibraryAddress;
    }

    public String getLibraryName(){
        return LibraryName;
    }

    public String getLibraryAddress(){
        return LibraryAddress;
    }

    @Override
    public String toString() {
        return "Library Name: " + LibraryName.toUpperCase()+ "\n" +
                "Library Address: " + LibraryAddress.toUpperCase() + "\n";
    }
}
